<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right" style="color: #111;">
            &copy;
            <script>
                document.write(new Date().getFullYear())

            </script>, made with <i class="material-icons">favorite</i>. Your Resume Generator!
        </div>
    </div>
</footer>
