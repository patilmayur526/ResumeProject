<div class="content">
	<div class="container-fluid">
		<div class="resume" style="border: solid 2px #313C43;border-radius: 20px;margin:30px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
			<div class="row">

				<div class="col-md-3">

					<section class="left">
						<img src="../../assets/img/faces/avatar.jpg" class="student-image" alt="">
						<div class="contact-details">
							<h2 class="contact-header">CONTACT</h2>
							<div class="col-md-12">
								<p>Contact No. 123456789</p><br>
								<p>Loaction. 123,dbhcbsxjzs,djdsnvkds</p><br>
								<p>mail. chirag@gmail.com</p><br><br>

							</div>
						</div>
					</section>
				</div>
				<div class="col-md-9">
					<section class="right">
						<h1 class="student-header">PAUL WAULSON</h1>
						<div class="black-box-lg">
							<p class="black-box-lg-text">WEB DESIGNER AND DEVELOPER</p>
						</div>
						<p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maxime voluptatibus sunt aperiam velit in quos consequuntur accusamus deleniti ipsum sit facere, minima rerum laboriosam optio itaque! Numquam, obcaecati excepturi magni.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit commodi harum neque officia, magni mollitia fuga alias corrupti at hic quas atque expedita sequi consequuntur voluptas, tempora, blanditiis fugiat vero!</p>

						<div class="right-bottom">
							<section class="section-1">
								<div class="row">
									<div class="upper-section-part">
										<h2 class="section-1-header">EXPERIENCE</h2>
									</div>
								</div>
								<div class="section-1-1">
									<div class="row">
										<div class="col-md-3">
											<div class="section1-left-part">
												<h3 class="section-headings">WEB <br>
													DEVELOPER</h3>
												<div class="section-black-box">
													<p class="section-black-box-text">2015-19</p>
												</div>
											</div>
										</div>

										<div class="col-md-9">
											<h4 class="experience-heading">LOREM IPSUM - United states</h4>
											<p class="text-section">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam libero quam dolore cum consectetur, quis, aliquid alias hic deserunt cumque nostrum qui. Alias sit ex ad. Sunt, culpa maiores voluptatem!</p>
										</div>
									</div>
								</div>
								<div class="section-1-1">
									<div class="row">
										<div class="col-md-3">
											<div class="section1-left-part">
												<h3 class="section-headings">GRAPHIC <br>
													DESIGNER</h3>
												<div class="section-black-box">
													<p class="section-black-box-text">2015-19</p>
												</div>
											</div>
										</div>

										<div class="col-md-9">
											<h4 class="experience-heading">LOREM IPSUM - United states</h4>
											<p class="text-section">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam libero quam dolore cum consectetur, quis, aliquid alias hic deserunt cumque nostrum qui. Alias sit ex ad. Sunt, culpa maiores voluptatem!</p>
										</div>
									</div>
								</div>
								<div class="section-1-1">
									<div class="row">
										<div class="col-md-3">
											<div class="section1-left-part">
												<h3 class="section-headings">3R WEB<br>
													DESIGNER</h3>
												<div class="section-black-box">
													<p class="section-black-box-text">2015-19</p>
												</div>
											</div>
										</div>

										<div class="col-md-9">
											<h4 class="experience-heading">LOREM IPSUM - United states</h4>
											<p class="text-section">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam libero quam dolore cum consectetur, quis, aliquid alias hic deserunt cumque nostrum qui. Alias sit ex ad. Sunt, culpa maiores voluptatem!</p>
										</div>
									</div>
								</div>

							</section>
							<section class="section-2">
								<div class="row">
									<div class="upper-section-part">
										<h2 class="section-1-header">EDUCATION</h2>
									</div>
								</div>
								<div class="section-1-1">
									<div class="row">
										<div class="col-md-3">
											<div class="section1-left-part">
												<h3 class="section-headings">ARTS <br>
													DEGREE</h3>
												<div class="section-black-box">
													<p class="section-black-box-text">2015-19</p>
												</div>
											</div>
										</div>

										<div class="col-md-9">
											<h4 class="experience-heading">LOREM IPSUM - United states</h4>
											<p class="text-section">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam libero quam dolore cum consectetur, quis, aliquid alias hic deserunt cumque nostrum qui. Alias sit ex ad. Sunt, culpa maiores voluptatem!</p>
										</div>
									</div>
								</div>
								<div class="section-1-1">
									<div class="row">
										<div class="col-md-3">
											<div class="section1-left-part">
												<h3 class="section-headings">EDU JR <br>
													SCHOOL</h3>
												<div class="section-black-box">
													<p class="section-black-box-text">2015-19</p>
												</div>
											</div>
										</div>

										<div class="col-md-9">
											<h4 class="experience-heading">LOREM IPSUM - United states</h4>
											<p class="text-section">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veniam libero quam dolore cum consectetur, quis, aliquid alias hic deserunt cumque nostrum qui. Alias sit ex ad. Sunt, culpa maiores voluptatem!</p>
										</div>
									</div>
								</div>

							</section>

							<section>

							</section>
						</div>
						<!--end of right-bottom-->
					</section>


				</div>

			</div>
		</div>
	</div>
</div>
