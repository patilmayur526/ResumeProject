# Resume-Generator
A Complete Resume Generator Based On php Framework(Code Igniter). the web app takes some user details and create a Resume of the style you like the most.

## Preview

![resume](https://user-images.githubusercontent.com/43413309/53590867-bc426580-3bb8-11e9-8320-609ea6deabcc.gif)


## Docs

### Running locally
No Dependiesces Needed just follow steps!
#### Steps: 
```sh

1. CLone Repo Locally inside your local Web Server Directory
2. Start your local server.
3. import database file in phpmyadmin db tool (steps are given below)
3. Open your browser to localhost/Resume

```

### Importing Database File

#### See [Importing MySQL databases and tables using phpMyAdmin](https://youtu.be/jW5lrS6EUPM)
```sh
Database Name should be resume_generator
```
```sh
Database File is Present Inside root/db_file
```
